# High CPU Utilization

## 1. What is the symptom?

The monitoring system generates an alert indicating that CPU utilization has suddenly reached **100%**. My first step is **not** to assume it is a production incident. Instead, I determine whether it is a **temporary (transient) spike** or a **sustained issue**. I check monitoring dashboards such as Grafana, Prometheus, Datadog, CloudWatch, or any enterprise monitoring tool to verify when the spike started, how long it has lasted, whether it is affecting one server or multiple servers, and whether there is any business impact such as increased response times, failed requests, timeout errors, or user complaints.

---

## 2. What metrics do I collect?

Before logging into the server, I collect production metrics to understand the overall situation.

I verify:

- CPU utilization trend -  A short spike may be caused by scheduled jobs, garbage collection, backups, or legitimate traffic and may not require intervention.
                            - A sustained high CPU usually indicates an application, infrastructure, or operating system problem.
- CPU saturation duration  -- Short duration → Usually expected workload.
                              - Long duration → Indicates CPU cannot keep up with incoming work and requires investigation.
- Response time      - - Normal response time → Application is still healthy.
                        - Increased response time → Requests are taking longer to process, indicating customer impact.
- Error rate  -Sometimes applications continue serving requests but begin returning errors.

I check:

- HTTP 500
- HTTP 502
- HTTP 503
- Timeout errors
- Failed API calls
  
- Request rate (Traffic) - If request volume suddenly doubles or triples, higher CPU utilization may simply be the result of legitimate business traffic rather than a system fault.
- Load average - - CPU = 100% but Load Average = 1 → Normal on a single-core system.
- CPU = 100% and Load Average = 50 → Many processes are waiting for CPU time.

High load average often indicates CPU saturation.

- Memory utilization
- Disk I/O - I verify:

- Disk latency
- Disk utilization
- I/O wait

If I/O wait is high, the CPU may appear busy while actually waiting for disk operations to complete.


My objective is to determine whether this is a resource issue, an application issue, or simply an expected workload.

---

## 3. What commands do I run?

Once I confirm that the CPU issue is persistent, I log in to the server and begin a systematic investigation.

### Check overall system utilization

```bash
top
```

or

```bash
htop
```

I observe:

- User CPU (us)
- System CPU (sy)
- Idle CPU (id)
- I/O Wait (wa)
- Steal Time (st)
- Load Average

---

### Identify the process consuming CPU

```bash
ps -aux --sort=-%cpu
```

or

```bash
top
```

I identify which process is consuming the CPU.

Examples:

- Java
- Nginx
- MySQL
- PostgreSQL
- Docker
- Kubernetes Pod
- Python
- Node.js

---

### Check memory

```bash
free -h
```
High CPU may not be the primary problem. I verify memory utilization to determine whether the system is under memory pressure or swapping, as CPU issues can sometimes be a symptom of insufficient memory.

**What does it tell me?**

It shows total, used, available memory, and swap usage. If memory is exhausted and swap is being used heavily, the system may be experiencing memory pressure, which can lead to increased kernel activity, high I/O wait, degraded application performance, and indirectly contribute to high system CPU.

> **Note:** `free -h` is not used because I suspect a memory issue—it is used to **eliminate memory as a possible root cause**.

---

### Check system statistics

```bash
vmstat 1
```
**Why do I check this?**

I use `vmstat` to obtain a real-time view of overall system health rather than looking at CPU alone.

**What does it tell me?**

It provides information about:

- Run queue (processes waiting for CPU)
- Blocked processes
- Context switches
- CPU utilization
- Memory usage
- Swap activity
- I/O activity

This helps determine whether the bottleneck is CPU, memory, or disk.

---
---

### Check disk performance

```bash
iostat -xz 1
```
**Why do I check this?**

Applications often perform disk operations while processing requests. Slow storage can significantly affect application performance.

**What does it tell me?**

It shows:

- Disk utilization (%util)
- Read/write throughput
- Disk latency
- Average wait time
- I/O queue depth

If disk utilization or latency is high, the application may be waiting for storage operations rather than being CPU-bound. This helps determine whether the storage subsystem is contributing to the performance issue.
---

### Historical statistics

```bash
sar
```

---

### Kernel messages

```bash
dmesg
```

---

### System logs

```bash
journalctl
```

---

## 4. What if CPU is normal?

If I log in and the CPU has already returned to normal, I don't immediately close the incident.

I verify:

- Was it just a temporary spike?
- Was a cron job running?
- Did a backup execute?
- Was there a JVM Garbage Collection?
- Was there a deployment?
- Was there a burst of legitimate traffic?

I correlate historical monitoring graphs to determine whether this behavior is expected or abnormal.

---

## 5. What if memory is normal?

If memory utilization is normal and there is no swapping, I eliminate memory as the primary cause and continue investigating CPU utilization.

---

## 6. What if disk is normal?

If disk latency, disk utilization, and I/O wait are all within normal limits, I eliminate storage as the bottleneck.

---

## 7. What if everything is normal?

If CPU, memory, disk, and network all appear healthy, I shift my investigation toward the application.

Possible causes include:

- Infinite loops
- Thread contention
- Excessive Garbage Collection
- Database queries
- API retries
- Connection pool exhaustion
- Deadlocks
- Application bugs

The absence of infrastructure issues usually indicates an application-level problem.

---

## 8. OS Internals

I analyze operating system behavior by checking:

- User CPU vs System CPU
- Context switches
- Run queue
- Interrupts
- Process states
- Kernel logs
- I/O Wait
- Load Average

This helps determine whether the operating system itself is under stress.

---

## 9. Application Internals

Once I identify the application consuming CPU, I investigate it further.

For Java applications:

```bash
top -H -p <PID>
```

Then collect a thread dump:

```bash
jstack <PID>
```

I check for:

- Infinite loops
- High Garbage Collection
- Thread contention
- Deadlocks
- Long-running requests
- Inefficient code

I also review:

- Application logs
- Error logs
- Exception stack traces
- Database queries
- External API calls
- Message queues

The objective is to identify **why** the application is consuming CPU.

---

## 10. Infrastructure Checks

I verify whether any recent infrastructure or environmental changes could have triggered the issue.

Examples include:

- Recent deployment
- Configuration changes
- Autoscaling events
- Load Balancer changes
- Kubernetes scheduling
- Backup jobs
- Cron jobs
- Security scans
- Traffic spikes
- Cloud infrastructure events

Many production issues are introduced immediately after operational changes.

---

## 11. Root Cause

Once sufficient evidence is collected, I determine the actual root cause.

Examples include:

- Infinite application loop
- High user traffic
- Inefficient SQL query
- Excessive JVM Garbage Collection
- Memory leak causing CPU pressure
- Background batch job
- Misconfigured cron job
- Infrastructure resource contention
- Bug introduced during deployment

The objective is to identify the actual cause rather than treating the symptom.

---

## 12. Resolution

If customers are impacted, restoring service becomes the priority.

Depending on the situation, I may:

- Remove the unhealthy instance from the load balancer
- Scale the application horizontally
- Increase resources
- Roll back a recent deployment
- Restart the application only after collecting diagnostic data
- Optimize the problematic process

Once service is restored, I continue investigating until the root cause is confirmed.

---

## 13. Prevention

After resolving the incident, I perform a detailed Root Cause Analysis (RCA).

Preventive actions may include:

- Code optimization
- JVM tuning
- SQL optimization
- Autoscaling improvements
- Better alert thresholds
- Capacity planning
- Cron job optimization
- Performance testing
- Monitoring enhancements
- Documentation updates

The goal is to prevent similar incidents from recurring.

---

## 14. Interview Follow-up Questions

Interviewers commonly ask follow-up questions such as:

- What is the difference between User CPU and System CPU?
- What does I/O Wait indicate?
- What if CPU returns to normal before you log in?
- What if only one Java thread is consuming CPU?
- How do you troubleshoot high CPU in Kubernetes?
- What if the process is MySQL?
- What if CPU is 100% but users are not impacted?
- How do you identify an infinite loop?
- When would you restart the application?
- How do you perform RCA after a CPU incident?

> **Senior SRE Mindset:** I never assume that high CPU itself is the root cause. I validate the alert, assess business impact, investigate systematically across the OS, application, and infrastructure layers, restore service if required, identify the root cause, and implement preventive measures to avoid recurrence.
