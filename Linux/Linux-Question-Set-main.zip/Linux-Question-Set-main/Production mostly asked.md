# Senior SRE / DevOps Real-Time Production Scenarios (Most Asked in Interviews)

## Level 1 – Basic (Asked in Almost Every Interview)

### Linux
- Server is slow. How do you troubleshoot?
- High CPU utilization.
- High memory utilization.
- Disk is 100% full.
- Disk I/O is high.
- Load average is increasing.
- Zombie process.
- Process stuck in D state.
- Too many open files.
- Service not starting.
- SSH not working.
- Filesystem mounted as read-only.
- Unexpected server reboot.
- Cron job not running.

---

### Networking
- Website is not accessible.
- DNS resolution issue.
- Port is not listening.
- Connection timeout vs Connection refused.
- High network latency.
- Packet loss.
- SSL certificate expired.
- Load balancer health checks failing.

---

### AWS
- EC2 instance unreachable.
- EC2 status check failed.
- ALB returning 502.
- ALB returning 504.
- Auto Scaling not launching instances.
- Security Group issue.
- Network ACL issue.
- Route Table issue.
- EBS volume full.
- S3 Access Denied.

---

### Docker
- Container keeps restarting.
- Container exits immediately.
- Docker image build failure.
- Volume not mounted.
- Docker daemon not starting.

---

### Kubernetes
- Pod in CrashLoopBackOff.
- Pod Pending.
- ImagePullBackOff.
- Node NotReady.
- PVC Pending.
- Service not accessible.
- Ingress not routing traffic.
- Deployment stuck.
- Pods restarting frequently.
- Resource limits exceeded.

---

### Jenkins / CI-CD
- Build failing.
- Jenkins agent offline.
- Pipeline stuck.
- Workspace full.
- Credentials issue.
- Deployment failed after successful build.

---

# Level 2 – Intermediate Production Scenarios

## 1. High CPU Usage

### Expected Troubleshooting Flow

```text
top
    ↓
vmstat 1
    ↓
ps aux --sort=-%cpu
    ↓
top -H -p <PID>
    ↓
Logs
    ↓
Root Cause
```

---

## 2. Memory Leak

### Expected Troubleshooting Flow

```text
free -h
    ↓
vmstat
    ↓
pmap
    ↓
jmap / Heap Dump
    ↓
Application Logs
```

---

## 3. High Disk I/O

### Expected Troubleshooting Flow

```text
iostat -x
    ↓
iotop
    ↓
vmstat
    ↓
df -h
    ↓
du -sh
```

---

## 4. Network Latency

### Expected Troubleshooting Flow

```text
ping
    ↓
traceroute
    ↓
ss / netstat
    ↓
tcpdump
    ↓
curl
    ↓
dig / nslookup
```

---

## 5. Java Application Hanging

### Expected Troubleshooting Flow

```text
top
    ↓
jstack
    ↓
jmap
    ↓
GC Logs
    ↓
Heap Dump Analysis
```

---

## 6. Kubernetes Pods Restarting

### Expected Troubleshooting Flow

```text
kubectl get pods
        ↓
kubectl describe pod
        ↓
kubectl logs
        ↓
Events
        ↓
Resource Limits
        ↓
Readiness/Liveness Probes
```

---

# Level 3 – Senior SRE Production Scenarios

## Infrastructure

- Website suddenly becomes slow.
- Server healthy but application is slow.
- Production outage during business hours.
- High load after marketing campaign.
- Production server becomes unreachable.
- One Availability Zone is failing.
- One EC2 instance unhealthy every night.
- CPU normal but application still slow.
- Memory normal but response time is high.
- Disk full in production and restart is not allowed.

---

## Linux

- Memory leak in production.
- Process consuming 100% CPU.
- Process stuck in D state.
- High load average with low CPU.
- Swap continuously increasing.
- Kernel panic.
- OOM Killer terminating applications.
- Filesystem corruption.
- File descriptor exhaustion.
- System time synchronization issues.

---

## Networking

- Website accessible internally but not externally.
- Application timeout between services.
- High latency for one API.
- SSL certificate expired.
- DNS propagation issue.
- Firewall blocking traffic.
- Packet drops.
- MTU mismatch.
- NAT Gateway issue.

---

## AWS

- ALB healthy but application unavailable.
- ALB returning intermittent 502/504.
- Auto Scaling not scaling.
- EC2 health checks failing.
- Route Table issue.
- Security Group issue.
- IAM permission issue.
- CloudWatch alarm triggered.
- RDS latency increased.
- EBS burst balance exhausted.

---

## Kubernetes

- Node NotReady.
- Pods healthy but users receive 503.
- Service not routing traffic.
- Ingress issue.
- PVC Pending.
- CoreDNS failure.
- Pod scheduling failure.
- ResourceQuota exceeded.
- Deployment successful but traffic still reaches old pods.
- Cluster Autoscaler not working.

---

## Docker

- Container repeatedly restarting.
- Container healthy but application unavailable.
- Docker daemon crash.
- Overlay filesystem issue.
- Container network issue.

---

## CI/CD

- Deployment failed.
- Rollback failed.
- Blue-Green deployment issue.
- Canary deployment issue.
- Pipeline hanging.
- Jenkins agents disconnected.
- Artifact mismatch.

---

## Databases

- Database latency increased.
- Deadlocks.
- Slow queries.
- Connection pool exhaustion.
- Replication lag.
- Database storage full.

---

## Observability

- Alert fired but application healthy.
- Application unhealthy but monitoring shows healthy.
- Missing metrics.
- Missing logs.
- Alert fatigue.
- False positives.

---

## Incident Management

### Typical Scenario

Production outage.

Explain your incident handling process.

### Expected Flow

```text
Alert Triggered
        ↓
Acknowledge Incident
        ↓
Assess Business Impact
        ↓
Identify Affected Services
        ↓
Collect Metrics & Logs
        ↓
Mitigate Impact
        ↓
Find Root Cause
        ↓
Permanent Fix
        ↓
Validation
        ↓
Postmortem (RCA)
        ↓
Automation / Preventive Actions
```

---

# Behavioral Production Questions

- Tell me about your biggest production outage.
- Describe a Sev-1 incident you handled.
- How did you identify the root cause?
- How did you communicate during the incident?
- When did you involve developers?
- How did you prevent recurrence?
- What automation did you implement afterward?
- Tell me about a failed deployment.
- Tell me about a monitoring failure.
- How do you prioritize multiple production alerts?
- Tell me about a difficult on-call incident.
- Describe a time you handled an outage under pressure.

---

# Topics to Master for Senior SRE Interviews

1. Linux Performance Troubleshooting
2. Process & Thread Analysis
3. CPU, Memory, Disk I/O, Swap Analysis
4. Linux Networking Troubleshooting
5. Kubernetes Production Troubleshooting
6. Docker Troubleshooting
7. AWS Infrastructure Troubleshooting
8. CI/CD Failure Analysis
9. Database Performance Troubleshooting
10. Monitoring & Observability (Prometheus, Grafana, CloudWatch)
11. Incident Management (Sev-1/Sev-2)
12. Root Cause Analysis (RCA)
13. High Availability & Disaster Recovery
14. Scaling & Performance Optimization
15. Automation (Bash, Python, Ansible, Terraform)
16. Production Deployment Strategies (Blue-Green, Canary, Rolling)
17. Security & IAM Troubleshooting
18. Logging & Debugging
19. System Design & Reliability
20. Real-Time Production Incident Handling
